<footer class="footer-copyright">
    <div class="footer-copyright text-center py-3"> <?php echo "&copy; Copyright MOTES " . date("Y") ?>
    </div>

</footer>